import ShowReviewPage from '../features/review/pages/ShowReviewPage'

const ReviewPage = () => {
  return (
    <ShowReviewPage/>
  )
}

export default ReviewPage