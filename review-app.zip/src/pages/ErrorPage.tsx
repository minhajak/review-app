
const ErrorPage = () => {
  return (
    <div>Page Not Found</div>
  )
}

export default ErrorPage