import WriteReviewPage from "../features/review/pages/WriteReviewPage";

const WriteReview = () => {
  return <WriteReviewPage />;
};

export default WriteReview;
